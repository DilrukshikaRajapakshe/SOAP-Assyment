/**
 * Student_Service_ImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package serice_impl;

public interface Student_Service_ImplService extends javax.xml.rpc.Service {
    public java.lang.String getStudent_Service_ImplAddress();

    public serice_impl.Student_Service_Impl getStudent_Service_Impl() throws javax.xml.rpc.ServiceException;

    public serice_impl.Student_Service_Impl getStudent_Service_Impl(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
