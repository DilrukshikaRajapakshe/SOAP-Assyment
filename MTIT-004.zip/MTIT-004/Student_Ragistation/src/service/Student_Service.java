package service;

import module.Student;

public interface Student_Service {
	public boolean insert(int id, String name, int age);
	public Student search(int id);
	public boolean delete(int id);
	public Student[] findAll();
}
